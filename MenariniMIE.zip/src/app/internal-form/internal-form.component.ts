import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-internal-form',
  templateUrl: './internal-form.component.html',
  styleUrls: ['./internal-form.component.css']
})
export class InternalFormComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
