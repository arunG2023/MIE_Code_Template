import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-external-form',
  templateUrl: './external-form.component.html',
  styleUrls: ['./external-form.component.css']
})
export class ExternalFormComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
