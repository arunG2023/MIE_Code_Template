import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ExternalFormComponent } from './external-form.component';

describe('ExternalFormComponent', () => {
  let component: ExternalFormComponent;
  let fixture: ComponentFixture<ExternalFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ExternalFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ExternalFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
