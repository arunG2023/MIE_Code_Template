import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-new-mie',
  templateUrl: './new-mie.component.html',
  styleUrls: ['./new-mie.component.css']
})
export class NewMIEComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
