import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NewMIEComponent } from './new-mie.component';

describe('NewMIEComponent', () => {
  let component: NewMIEComponent;
  let fixture: ComponentFixture<NewMIEComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NewMIEComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NewMIEComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
